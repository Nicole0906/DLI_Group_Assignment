import gradio as gr
from phishing_utils import load_model_bytes, predict_proba

# Keep model in memory after first upload (small cache)
_MODEL_BUNDLE = {"bundle": None}

def _predict(url: str, weights_file) -> tuple:
    """Gradio callback: returns (Label_dict, details_text)."""
    if not url or not url.strip():
        return {"legit": 0.0, "phishing": 0.0}, "Please enter a URL."


    # Load/refresh weights if file provided
    try:
        if weights_file is not None:
            with open(weights_file.name, "rb") as f:
                _MODEL_BUNDLE["bundle"] = load_model_bytes(f.read())
    except Exception as e:
        return {"legit": 0.0, "phishing": 0.0}, f"Failed to load weights: {e}"

    if _MODEL_BUNDLE["bundle"] is None:
        return {"legit": 0.0, "phishing": 0.0}, "Please upload trained weights (.joblib/.pkl) before predicting."
    
    try:
        probs = predict_proba(url, _MODEL_BUNDLE["bundle"])
        pred = max(probs, key=probs.get)
        details = f"Prediction: {pred}\nProbabilities: legit={probs['legit']:.4f}, phishing={probs['phishing']:.4f}"
        # gr.Label expects a mapping of class → score
        return {"legit": probs["legit"], "phishing": probs["phishing"]}, details
    except Exception as e:
        return {"legit": 0.0, "phishing": 0.0}, str(e)
    
desc = "Upload your trained weights, then enter a single URL to classify."
with gr.Blocks(title="Phishing URL Detector") as demo:
    gr.Markdown("# 🛡️ Phishing URL Detector\n" + desc)
    with gr.Row():
        url_in = gr.Textbox(label="URL", placeholder="https://example.com/login")
        weights_in = gr.File(label="Weights (.joblib or .pkl)")
    predict_btn = gr.Button("Predict")
    out_label = gr.Label(label="Class Probabilities (higher = more likely)")
    out_text = gr.Textbox(label="Details")


    predict_btn.click(_predict, inputs=[url_in, weights_in], outputs=[out_label, out_text])


if __name__ == "__main__":
    # share=True → generates a public link in console
    demo.launch(share=True)