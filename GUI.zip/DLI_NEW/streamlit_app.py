import streamlit as st


# Local import from the same folder
# (If you run into import issues, ensure files are in the same directory.)
from phishing_utils import load_model_bytes, predict_proba


st.set_page_config(page_title="Phishing URL Detector (Streamlit)", page_icon="🛡️", layout="centered")
st.title("🛡️ Phishing URL Detector")
st.caption("Upload trained weights → enter a URL → click Predict")

uploaded = st.file_uploader("Upload trained weights (.joblib or .pkl)", type=["joblib", "pkl"])
model_bundle = None
if uploaded is not None:
    try:
        model_bundle = load_model_bytes(uploaded.read())
        st.success("Weights loaded successfully.")
    except Exception as e:
        st.error(f"Failed to load weights: {e}")


url = st.text_input("Enter a single URL")

if st.button("Predict"):
    if not url:
        st.warning("Please enter a URL first.")
    elif model_bundle is None:
        st.warning("Please upload trained weights before predicting.")
    else:
        try:
            probs = predict_proba(url, model_bundle)
            pred = max(probs, key=probs.get)
            st.write({"prediction": pred, "probabilities": probs})
        except Exception as e:
            st.error(str(e))
            