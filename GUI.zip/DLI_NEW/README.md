==============================
# README (Quickstart)
# ==============================
1) Create a new folder and save the three files below as:
- phishing_utils.py
- streamlit_app.py
- gradio_app.py
- (optional) train_example.py ← helper to train & export weights

2) Install deps (one time):
pip install -U scikit-learn joblib pandas tldextract validators streamlit gradio

3) Run Streamlit GUI: (run on powershell)
python -m streamlit run streamlit_app.py

4) Run Gradio GUI (public share link will be printed because share=True):
python gradio_app.py

# Notes
- Both apps allow you to upload a trained weights file (e.g., weights_demo.joblib).
- Both apps accept a single URL input and display class probabilities.