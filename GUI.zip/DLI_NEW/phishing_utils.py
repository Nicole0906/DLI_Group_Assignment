from __future__ import annotations
import io
import math
import re
from typing import Dict, Tuple, Optional, List
from urllib.parse import urlparse

import numpy as np

try:
    import joblib
except Exception as e:
    joblib = None

try:
    import tldextract # better URL parsing for domain/TLD
except Exception:
    tldextract = None

try:
    import validators
except Exception:
    validators = None

_SHORTENERS = {
"bit.ly", "tinyurl.com", "goo.gl", "ow.ly", "t.co", "is.gd", "buff.ly",
"adf.ly", "bit.do", "cutt.ly", "v.gd", "sh.st", "tr.im", "db.tt", "lc.chat"
}
_SUSPICIOUS_WORDS = [
"login", "update", "verify", "account", "secure", "webscr", "ebayisapi",
"banking", "confirm", "password", "reset"
]

def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    from collections import Counter
    counts = Counter(s)
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())




def _is_ip(netloc: str) -> bool:
    # very light check for IPv4 or dotted decimal in netloc
    return bool(re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", netloc.split(":")[0]))




def _safe_validate_url(url: str) -> str:
    if not url:
        return ""
    url = url.strip()
    # add scheme if missing to keep parsers happy
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "http://" + url
    return url

def _domain_parts(netloc: str) -> Tuple[str, str, str]:
    """Return (subdomain, domain, suffix). Fallback if tldextract missing."""
    if tldextract is not None:
        ext = tldextract.extract(netloc)
    return ext.subdomain, ext.domain, ext.suffix
    # naive fallback
    parts = netloc.split(":")[0].split(".")
    if len(parts) >= 2:
        domain = parts[-2]
        suffix = parts[-1]
        subdomain = ".".join(parts[:-2])
    else:
        domain = parts[0]
        suffix = ""
        subdomain = ""
    return subdomain, domain, suffix

def get_feature_names() -> List[str]:
    return [
    "url_len", "hostname_len", "path_len", "query_len", "num_dots", "num_hyphens",
    "has_at", "uses_https", "has_ip", "num_digits", "digit_ratio", "num_subdomains",
    "tld_len", "has_shortener", "suspicious_word_count", "entropy"
    ]

def extract_features(url: str) -> np.ndarray:
    url = _safe_validate_url(url)
    parsed = urlparse(url)
    netloc = parsed.netloc or ""
    path = parsed.path or ""
    query = parsed.query or ""

    subdomain, domain, suffix = _domain_parts(netloc)

    url_len = len(url)
    hostname_len = len(netloc)
    path_len = len(path)
    query_len = len(query)
    num_dots = netloc.count(".")
    num_hyphens = netloc.count("-")
    has_at = int("@" in url)
    uses_https = int(parsed.scheme.lower() == "https")
    has_ip = int(_is_ip(netloc))
    digits = sum(ch.isdigit() for ch in url)
    num_digits = digits
    digit_ratio = (digits / max(1, url_len))
    num_subdomains = len([p for p in subdomain.split(".") if p]) if subdomain else 0
    tld_len = len(suffix)
    registered = ".".join(x for x in [domain, suffix] if x)
    has_shortener = int(registered.lower() in _SHORTENERS)
    suspicious_word_count = sum(1 for w in _SUSPICIOUS_WORDS if w in url.lower())
    entropy = _shannon_entropy(url)

    feats = np.array([
        url_len, hostname_len, path_len, query_len, num_dots, num_hyphens,
        has_at, uses_https, has_ip, num_digits, digit_ratio, num_subdomains,
        tld_len, has_shortener, suspicious_word_count, entropy
    ], dtype=float).reshape(1, -1)
    return feats

def load_model_bytes(file_bytes: bytes) -> Dict:
    if joblib is None:
        raise RuntimeError("joblib is required to load weights. Please `pip install joblib`.\n")
    bundle = joblib.load(io.BytesIO(file_bytes))
    # Allow either dict bundle or a plain estimator
    if isinstance(bundle, dict) and "model" in bundle:
        model = bundle["model"]
        feature_names = bundle.get("feature_names", get_feature_names())
        version = bundle.get("version", 1)
        return {"model": model, "feature_names": feature_names, "version": version}
    else:
    # Plain estimator fallback
        return {"model": bundle, "feature_names": get_feature_names(), "version": 1}
    
def ensure_valid_url_or_raise(url: str) -> str:
    url = _safe_validate_url(url)
    if validators is not None:
        if not validators.url(url):
            raise ValueError("The provided text does not look like a valid URL.")
    # If validators not available, be permissive
    return url

def predict_proba(url: str, model_bundle: Dict) -> Dict[str, float]:
    url = ensure_valid_url_or_raise(url)
    feats = extract_features(url)
    model = model_bundle.get("model") if model_bundle else None
    if model is None:
        raise RuntimeError("No model loaded. Please upload trained weights first.")
    proba = None
    if hasattr(model, "predict_proba"):
        proba = model.predict_proba(feats)[0]
        # Try to map classes to human-readable labels
        classes = getattr(model, "classes_", [0, 1])
        label_map = {0: "legit", 1: "phishing"}
        out = {label_map.get(int(c), str(c)): float(p) for c, p in zip(classes, proba)}
    else:
    # If model lacks predict_proba, attempt decision_function → sigmoid
        if hasattr(model, "decision_function"):
            from math import exp
            score = float(model.decision_function(feats))
            p1 = 1 / (1 + exp(-score))
            out = {"legit": 1 - p1, "phishing": p1}
        else:
            raise RuntimeError("Model does not support probability output.")
    # Ensure both keys exist for UI stability
    out.setdefault("legit", 1.0 - out.get("phishing", 0.0))
    out.setdefault("phishing", 1.0 - out.get("legit", 0.0))
    return out

